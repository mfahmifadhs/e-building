

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('admin-master/dashboard')); ?>" style="color:#17a2b8;">Dashboard</a>
          </li>
          <li class="breadcrumb-item active"><b>Data Penilaian</b></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>   
        <?php if($message = Session::get('failed')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>        
        <?php if($message = Session::get('delete')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title-data"><b>Data Penilaian Pegawai</b></h3>  
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="table4" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>No </th>
                <th>NIP </th>
                <th>Petugas</th>
                <th>Penilaian</th>
                <th>Keterangan</th>
                <th>Area Kerja</th>
                <th>Pengawas</th>
                <th>Tanggal</th>
              </tr>
              </thead>
              <tbody style="font-size:13px;">
                <?php $no=1;?>
                <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($data->id_employee); ?></td>
                  <td><?php echo e($data->emp_name); ?></td>
                  <td><?php echo e($data->criteria_name); ?></td>
                  <td><?php echo e($data->description); ?></td>
                  <td>
                      <?php if($data->score_notes != null): ?>
                        <?php echo e($data->score_notes); ?>

                      <?php endif; ?>
                      <?php if($data->score_notes == null): ?>
                        <?php echo e($data->working_area_name); ?>

                      <?php endif; ?>
                  </td>
                  <td><?php echo e($data->name); ?></td>
                  <td><?php echo e(date('H:i', strtotime($data->score_tm))); ?> / <?php echo e(\Carbon\Carbon::parse($data->score_dt)->isoFormat('DD MMM Y')); ?>

                  </td>
                  
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
              <tr>
                <th>No </th>
                <th>NIP </th>
                <th>Petugas</th>
                <th>Penilaian</th>
                <th>Keterangan</th>
                <th>Area Kerja</th>
                <th>Pengawas</th>
                <th>Tanggal</th>
              </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_admin/show_report.blade.php ENDPATH**/ ?>