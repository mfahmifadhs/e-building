

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Kriteria Penilaian</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('pengawas/dashboard')); ?>" style="color:#17a2b8;">Dashboard</a>
          </li>
          <li class="breadcrumb-item active"><b>Kriteria Penilaian</b></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!-- /.content-header -->

<!-- Main content -->
<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">

    <!-- KRITERIA PT. SENDIKA -->
    <?php if($data->id == 2): ?>
      <div class="col-md-6">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title-data"><b>Kriteria Penilaian Banquet & MM</b></h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="table1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </thead>
              <tbody>
                <?php $no=1;?>
                <?php $__currentLoopData = $banquetmm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($row->criteria_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>

      <div class="col-md-6">
        <div class="card card-success">
          <div class="card-header">
            <h3 class="card-title-data"><b>Kriteria Penilaian Taman</b></h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="table1a" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </thead>
              <tbody>
                <?php $no=1;?>
                <?php $__currentLoopData = $gardener; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($row->criteria_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    <?php endif; ?>

    <!-- KRITERIA PT. ALFIRA -->
    <?php if($data->id == 3): ?>
      <div class="col-md-12">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title-data"><b>Kriteria Penilaian Banquet & Multimedia</b></h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="table1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </thead>
              <tbody>
                <?php $no=1;?>
                <?php $__currentLoopData = $banquetmm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($row->criteria_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <!-- KRITERIA PT. TRANS DANA -->
    <?php if($data->id == 4): ?>
      <div class="col-md-12">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title-data"><b>Kriteria Penilaian Security</b></h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="table1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </thead>
              <tbody>
                <?php $no=1;?>
                <?php $__currentLoopData = $security; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($row->criteria_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
              <tr>
                <th>No </th>
                <th>Nama Kriteria</th>
              </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    <?php endif; ?>

    </div>
  </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_vendor.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_vendor/show_criteria.blade.php ENDPATH**/ ?>