

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">

    </div>
  </div>
</section>
<!-- Content Header (Page header) -->


<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
       		<?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                  <p style="margin:0;"><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>        
          <?php if($message = Session::get('delete')): ?>
              <div class="alert alert-danger">
                  <p style="margin:0;"><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
		          <div class="alert alert-danger">
		              <ul>
		                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                      <?php echo e($error); ?>

		                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              </ul>
		          </div>
		      <?php endif; ?>
		      <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <div class="row">
		      	<div class="col-md-12">
	            <div class="card card-primary">
	              <div class="card-header">
	                <h3 class="card-title"><b>DATA PETUGAS (<?php echo e($data->emp_name); ?> - <?php echo e($data->name); ?>)</b></h3>
	                <div class="card-tools">
	                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
	                    <i class="fas fa-minus"></i>
	                  </button>
	                </div>
	              </div>
	              <!-- /.card-header -->
	              <div class="card-body">
	                <div class="row">
		                <div class="col-md-6">
			                <label>Penyedia :</label>
		                	<div class="form-group input-group mb-3">
		                		<input type="text" class="form-control" value="<?php echo e($data->name); ?>" readonly>
			                	<div class="input-group-append">
								           <div class="input-group-text">
								             <span class="fas fa-building"></span>
								           </div>
							        	</div>
		                	</div>
		                </div>                	
		                <div class="col-md-6">
		                	<label>Posisi :</label>
		                	<div class="form-group input-group mb-3">
			                	<select class="form-control" name="emp_position" readonly>
			                		<option value="<?php echo e($data->emp_position); ?>"><?php echo e($data->emp_position); ?></option>
			                	</select>
			                	<div class="input-group-append">
							            <div class="input-group-text">
							              <span class="fas fa-user"></span>
							            </div>
							        	</div>
		                	</div>
		                </div>                	
		                <div class="col-md-6">
		                	<label>Nama Pegawai :</label>
		                	<div class="form-group input-group mb-3">
			                	<input type="text" class="form-control" name="emp_name" value="<?php echo e($data->emp_name); ?>" placeholder="<?php echo e($data->emp_name); ?>" readonly>
			                	<div class="input-group-append">
							            <div class="input-group-text">
							              <span class="fas fa-id-card"></span>
							            </div>
							        	</div>
		                	</div>
		                </div> 
		                <div class="col-md-6">
			                <label>	No. Handphone :</label>
		                	<div class="form-group input-group mb-3">
			                	<input type="text" class="form-control" name="emp_phone_number" value="<?php echo e($data->emp_phone_number); ?>" readonly>
			                	<div class="input-group-append">
							            <div class="input-group-text">
							              <span class="fas fa-phone-square"></span>
							            </div>
							        	</div>
		                	</div>
		                </div>  
		                <div class="col-md-6">
			                <label>	Jenis Kelamin :</label>
		                	<div class="form-group input-group mb-3">
			                	<select class="form-control" name="gender" readonly>
			                		<option value="<?php echo e($data->emp_gender); ?>"><?php echo e($data->emp_gender); ?></option>
			                	</select>
			                	<div class="input-group-append">
							            <div class="input-group-text">
							              <span class="fas fa-venus-double"></span>
							            </div>
							        	</div>
		                	</div>
		                </div>  
		                <div class="col-md-6">
			                <label>	Agama :</label>
		                	<div class="form-group input-group mb-3">
			                	<select class="form-control" name="religion" readonly>
			                		<option value="<?php echo e($data->emp_religion); ?>"><?php echo e($data->emp_religion); ?></option>
			                	</select>
			                	<div class="input-group-append">
							            <div class="input-group-text">
							              <span class="fas fa-pray"></span>
							            </div>
							        	</div>
		                	</div>
		                </div>  
		                <div class="col-md-6">
			                <label>	Alamat :</label>
		                		<div class="form-group input-group mb-3">
			                	<input type="text" class="form-control" name="emp_address" value="<?php echo e($data->emp_address); ?>" readonly>
			                	<div class="input-group-append">
							            <div class="input-group-text">
							              <span class="fas fa-house-user"></span>
							            </div>
							        	</div>
		                	</div>
		                </div>   
		                <div class="col-md-6">
			                <label>	Status :</label>
		                	<div class="form-group input-group mb-3">
			                	<select class="form-control" name="status_id" readonly>
			                		<option value="<?php echo e($data->status_id); ?>" readonly><b><?php echo e($data->status_name); ?></b></option >
			                	</select>
			                	<div class="input-group-append">
							            <div class="input-group-text">
							              <span class="fas fa-house-user"></span>
							            </div>
							        	</div>
		                	</div>
		                </div> 	 
	                </div>
	              </div>
	              <!-- /.card-body -->
	            </div>
	          </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</section>

<!-- Section Penilaian Header -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">

    </div>
  </div>
</section>
<!-- Section Penilaian Header -->

<!-- Scoring Content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
		      
      	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <div class="row">
		      	<div class="col-md-12">
	            <div class="card card-warning">
	              <div class="card-header">
	                <h3 class="card-title"><b>TEMUAN KARTU KUNING (<?php echo e($data->emp_name); ?> - <?php echo e($data->name); ?>)</b></h3>
	                <div class="card-tools">
	                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
	                    <i class="fas fa-minus"></i>
	                  </button>
	                </div>
	              </div>
	              <!-- /.card-header -->
	              <div class="card-body">
	              	<form action="<?php echo e(url('pengawas/add_score/')); ?>" method="POST">
	              		<input type="hidden" name="emp_id" value="<?php echo e($data->id_employee); ?>">
	              		<input type="hidden" name="working_area_id" value="<?php echo e($workingarea->id_working_area); ?>">
	              		<input type="hidden" name="score_notes" value="<?php echo e($scorenote); ?>" style="text-transform:uppercase;">
	              		<?php echo csrf_field(); ?>
	                	<div class="row">
		                	<div class="col-md-6">
		                    <label>Nama Pegawai :</label>
		                    <div class="form-group input-group mb-3">
		                    	<input type="text" class="form-control" value="<?php echo e($data->emp_name); ?>" readonly>
		                      <div class="input-group-append">
							            	<div class="input-group-text">
							              	<span class="fas fa-building"></span>
							            	</div>
							        		</div>
		                    </div>
		                  </div> 
		                	<div class="col-md-6">
		                    <label>Area Kerja :</label>
		                    <div class="form-group input-group mb-3">
		                    	<input type="text" class="form-control" value="<?php echo e($workingarea->working_area_name); ?>" readonly>
		                      <div class="input-group-append">
							            	<div class="input-group-text">
							              	<span class="fas fa-building"></span>
							            	</div>
							        		</div>
		                    </div>
		                  </div>

		                  <div class="col-md-12">
		                  	<hr><br>
		                    <div class="form-group">
		                      <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                      <div class="row">
		                        <div class="col-md-6">
		                        	<div class="form-group">
			                        	<input type="hidden" name="criteria_id[]" value="<?php echo e($data->id_criteria); ?>">
			                          <?php echo e($data->criteria_name); ?> : 
		                        	</div>
		                        </div>
		                        <div class="col-md-2">
		                        	<div class="form-group">
		                          	<input type="checkbox" class="form-control" name="score[<?php echo e($data->id_criteria); ?>]" value="1">
		                          </div>
		                        </div>
		                        <div class="col-md-4">
		                        	<div class="form-group input-group mb-3">
		                        		<input type="text" class="form-control" name="description[]" placeholder="Masukan keterangan">
		                        		<div class="input-group-append">
										            	<div class="input-group-text">
										              	<span class="fas fa-file-medical"></span>
										            	</div>
										        		</div>
		                        	</div>
		                        </div>
		                      </div>
		                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    </div>
		                  </div>
		                  <div class="col-md-6">
		                  	<div class="form-group">
		                  		<button type="submit" class="btn btn-info form-control">TAMBAH</button>
		                  	</div>
		                  </div>
		                  <div class="col-md-6">
		                  	<div class="form-group">
		                  		<button type="reset" class="btn btn-danger form-control" value="reset">BATAL</button>
		                  	</div>
		                  </div>    
	                	</div>
	                </form>
	              </div>
	              <!-- /.card-body -->
	            </div>
	          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_pengawas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_pengawas/create_score.blade.php ENDPATH**/ ?>