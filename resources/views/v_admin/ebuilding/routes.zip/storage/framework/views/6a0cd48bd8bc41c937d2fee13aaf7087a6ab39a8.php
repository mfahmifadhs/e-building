
<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-12">

      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
           <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>        
        <?php if($message = Session::get('failed')): ?>
          <div class="alert alert-danger">
            <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
		      <div class="alert alert-danger">
		        <ul>
		          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <?php echo e($error); ?>

		          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		      </div>
		   	<?php endif; ?>
        <div class="card">
          <div class="card-header" style="background-color:#11B7AE;color: white;">
            <h3 class="card-title-data"><b>Edit Pengguna - <?php echo e($data->name); ?></b></h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
	          <form action="<?php echo e(url('admin-master/update_vendor/'. $data->id)); ?>" method="post">
	          	<input type="hidden" name="id" value="<?php echo e($data->id); ?>">
	            <?php echo csrf_field(); ?>
	            <div class="row">
			          <div class="col-md-6">
				          <label>Pilih Role :</label>
			            <div class="form-group input-group mb-3">
				            <select class="form-control" name="role_id" readonly>
					            <option value="<?php echo e($data->role_id); ?>"><?php echo e($data->role_name); ?></option>
				            </select>
				            <div class="input-group-append">
								      <div class="input-group-text">
								        <span class="fas fa-user-tag"></span>
								      </div>
								    </div>
			            </div>
			          </div>                	
	              <div class="col-md-6">
	               <label>Username :</label>
	               <div class="form-group input-group mb-3">
		               	<input type="username" class="form-control" name="username" value="<?php echo e($data->username); ?>" minlength= "8" readonly>
		               	<div class="input-group-append">
							        <div class="input-group-text">
							           <span class="fas fa-envelope"></span>
							        </div>
						       	</div>
	               </div>
	              </div>                	
		            <div class="col-md-6">
		              <label>Nama Pengawas / Perusahaan Penyedia :</label>
		              <div class="form-group input-group mb-3">
			             	<input type="text" class="form-control" name="name" value="<?php echo e($data->name); ?>" required>
				            <div class="input-group-append">
									    <div class="input-group-text">
									      <span class="fas fa-id-card"></span>
									    </div>
								    </div>
		              </div>
		            </div>
	              <div class="col-md-6">
		            	<label>Pilih Status :</label>
	              	<div class="form-group input-group mb-3">
		                <select class="form-control" name="status_id">
		                	<?php if($data->status_id == '1'): ?>
		                		<option value="1">Aktif</option>
		                		<option value="0">Tidak Aktif</option>
		                	<?php endif; ?>
		                	<?php if($data->status_id == '0'): ?>
		                		<option value="0">Tidak Aktif</option>
		                		<option value="1">Aktif</option>
		                	<?php endif; ?>
		               	</select>
		               	<div class="input-group-append">
							      	<div class="input-group-text">
							        	<span class="fas fa-user-tag"></span>
							        </div>
						       	</div>
	               	</div>
	              </div>                  	
	              <div class="col-md-6">
	              	<label>&nbsp;</label>
	              	<button type="submit" class="form-control btn btn-info" onclick="return confirm('Yakin ingin mengubah data ?')">UBAH</button>
	              </div>
              </div>
            </form>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_admin/edit_vendor.blade.php ENDPATH**/ ?>