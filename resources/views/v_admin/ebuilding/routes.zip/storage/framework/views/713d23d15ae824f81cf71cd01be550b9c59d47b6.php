

    <?php $__env->startSection('content'); ?>

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12">
            
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Building content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p style="margin:0;"><?php echo e($message); ?></p>
            </div>
          <?php endif; ?>        
          <?php if($message = Session::get('delete')): ?>
            <div class="alert alert-danger">
                <p style="margin:0;"><?php echo e($message); ?></p>
            </div>
          <?php endif; ?>
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title-data"><b>Data Gedung KEMENKES</b></h3>
              <a href="#add-building" data-toggle="modal" data-target="#add-building" class="btn btn-primary add-data">
                <i class="fas fa-plus-circle"></i>
              </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No </th>
                  <th>Nama Gedung</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php $no=1;?>
                  <?php $__currentLoopData = $building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($data->building_name); ?></td>
                    <td class="text-center">
                      <a href="#edit-building" data-toggle="modal" data-target="#edit-building<?php echo e($data->id_building); ?>" class="btn btn-warning add-data"><i class="fas fa-edit"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>No </th>
                  <th>Nama Gedung</th>
                  <th>Aksi</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> 

  <!-- Building content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title-data"><b>Data Area Gedung KEMENKES</b></h3>
              <a href="#add-floor" data-toggle="modal" data-target="#add-floor" class="btn btn-primary add-data">
                <i class="fas fa-plus-circle"></i>
              </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No </th>
                  <th>Nama Gedung</th>
                  <th>Lantai</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php $no=1;?>
                  <?php $__currentLoopData = $floor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($data->building_name); ?></td>
                    <td><?php echo e($data->floor_name); ?></td>
                    <td class="text-center">
                      <a href="#edit-floor" data-toggle="modal" data-target="#edit-floor<?php echo e($data->id_floor); ?>" class="btn btn-warning add-data">
                        <i class="fas fa-edit"></i>
                      </a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th>No </th>
                    <th>Nama Gedung</th>
                    <th>Lantai</th>
                    <th>Aksi</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> 

    

  <!-- Modal Add Building -->
	<div class="modal fade" id="add-building" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header" style="background-color:#11B7AE;color: white;">
	        <h5 class="modal-title" id="exampleModalLabel"><b>Tambah Data Gedung</b></h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <form action="<?php echo e(url('admin-master/add_building/')); ?>" method="POST">
	      	<?php echo csrf_field(); ?>
		      <div class="modal-body">
		        	<div class="row">        		
		        		<div class="col-md-12">
		        			<div class="form-group">
		        				<label>Nama Gedung :</label>
			        			<input type="text" class="form-control" name="building_name" placeholder="Nama Gedung">
		        			</div>
		        		</div>
		        	</div>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-info">Tambah</button>
		      </div>
	      </form>
	    </div>
	  </div>
	</div>    

  <!-- Modal Add Floor -->
  <div class="modal fade" id="add-floor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#11B7AE;color: white;">
          <h5 class="modal-title" id="exampleModalLabel"><b>Tambah Data Area Gedung</b></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(url('admin-master/add_floor/')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Nama Gedung :</label>
                    <select class="form-control" name="building_id">
                      <option>-- Pilih Gedung --</option>
                      <?php $__currentLoopData = $building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id_building); ?>"><?php echo e($data->building_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>              
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Nama Lantai :</label>
                    <input type="text" class="form-control" name="floor_name" placeholder="Nama Lantai">
                  </div>
                </div>
              </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-info">Tambah</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <?php $__currentLoopData = $building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <!-- Modal Edit Building -->
  <div class="modal fade" id="edit-building<?php echo e($data->id_building); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#11B7AE;color: white;">
          <h5 class="modal-title" id="exampleModalLabel"><b>Edit Nama Gedung - <?php echo e($data->building_name); ?></b></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(url('admin-master/update_building/'. $data->id_building )); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Edit Nama Gedung :</label>
                    <input type="text" class="form-control" name="building_name" value="<?php echo e($data->building_name); ?>">
                  </div>
                </div>
              </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-info">Ubah</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $floor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <!-- Modal Edit Floor -->
  <div class="modal fade" id="edit-floor<?php echo e($data->id_floor); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#11B7AE;color: white;">
          <h5 class="modal-title" id="exampleModalLabel"><b>Edit Area - <?php echo e($data->floor_name); ?></b></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(url('admin-master/update_floor/'. $data->id_floor )); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
                            <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Nama Gedung :</label>
                    <select class="form-control" name="building_id">
                      <option>-- Pilih Gedung --</option>
                      <?php $__currentLoopData = $building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id_building); ?>"
                        <?php if($row->building_name == $data->building_name) echo "selected"; ?>>
                        <?php echo e($row->building_name); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>              
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Nama Lantai :</label>
                    <input type="text" class="form-control" name="floor_name" placeholder="Nama Lantai" value="<?php echo e($data->floor_name); ?>">
                  </div>
                </div>
              </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-info">Ubah</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_admin/show_building.blade.php ENDPATH**/ ?>