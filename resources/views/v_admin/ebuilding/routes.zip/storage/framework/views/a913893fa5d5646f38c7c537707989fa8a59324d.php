

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('admin-master/dashboard')); ?>" style="color:#17a2b8;">Dashboard</a>
          </li>
          <li class="breadcrumb-item active"><b>Data Penilaian</b></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <!-- Info Boxes Style 2 -->
          <div class="card card-primary card-outline">
            <div class="card-body">
              <form action="<?php echo e(url('admin-master/search_score')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-md-2">
                    <label>Pilih Tanggal: </label>
                    <div class="form-group">
                      <input type="date" name="start_dt" class="form-control">
                    </div>
                  </div>
                  <div class="col-md-1">
                    <label>&nbsp;</label>
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="-" readonly style="text-align:center;font-weight: bold;">
                    </div>
                  </div>
                  <div class="col-md-2">
                    <label>&nbsp;</label>
                    <div class="form-group">
                      <input type="date" name="end_dt" class="form-control">
                    </div>
                  </div>
                  <div class="col-md-5">
                    <label>Pilih Petugas:</label>
                    <div class="form-group">
                      <select class="form-control" name="emp_category">
                        <option value="">-- Pilih Petugas --</option>
                        <option value="bm">BANQUET & MULTIMEDIA</option>
                        <option value="cs">CLEANING SERVICES</option>
                        <option value="sc">SECURITY</option>
                        <option value="gd">TAMAN</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <label>&nbsp;</label>
                    <p>
                      <button class="btn btn-info"><b>CARI</b></button>
                      <a href="<?php echo e(url('admin-master/show_score_all')); ?>" class="btn btn-danger">
                        <i class="fas fa-sync"></i>
                      </a>
                    </p>
                  </div>    
                </div>
              </form>
            </div>
          </div>
      </div>

      <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>   
        <?php if($message = Session::get('failed')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>        
        <?php if($message = Session::get('delete')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title-data"><b>DATA PENILAIAN PEGAWAI</b></h3>  
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="table4" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>No </th>
                <th>NIP </th>
                <th>Petugas</th>
                <th>Penilaian</th>
                <th>Keterangan</th>
                <th>Area Kerja</th>
                <th>Pengawas</th>
                <th>Kategori</th>
                <th>Tanggal</th>
                <th>Aksi</th>
              </tr>
              </thead>
              <tbody style="font-size:13px;">
                <?php $no=1;?>
                <?php $__currentLoopData = $score; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($data->id_employee); ?></td>
                  <td><?php echo e($data->emp_name); ?></td>
                  <td><?php echo e($data->criteria_name); ?></td>
                  <td><?php echo e($data->description); ?></td>
                  <td>
                      <?php if($data->score_notes != null): ?>
                        <?php echo e($data->score_notes); ?>

                      <?php endif; ?>
                      <?php if($data->score_notes == null): ?>
                        <?php echo e($data->working_area_name); ?>

                      <?php endif; ?>
                  </td>
                  <td><?php echo e($data->name); ?></td>
                  <td class="text-center">
                    <?php if($data->emp_category == 'CS'): ?>
                      <a class="btn btn-primary btn-sm disabled font-weight-bold">CS</a>
                    <?php endif; ?>
                    <?php if($data->emp_category == 'MM'): ?>
                      <a class="btn btn-warning btn-sm disabled font-weight-bold">MM</a>
                    <?php endif; ?>
                    <?php if($data->emp_category == 'BQ'): ?>
                      <a class="btn btn-warning btn-sm disabled font-weight-bold">BQ</a>
                    <?php endif; ?>
                    <?php if($data->emp_category == 'GD'): ?>
                      <a class="btn btn-success btn-sm disabled font-weight-bold">GD</a>
                    <?php endif; ?>
                    <?php if($data->emp_category == 'SC'): ?>
                      <a class="btn btn-dark btn-sm disabled font-weight-bold">SC</a>
                    <?php endif; ?>
                  </td>
                  <td><?php echo e(date('H:i', strtotime($data->score_tm))); ?> / 
                      <?php echo e(\Carbon\Carbon::parse($data->score_dt)->isoFormat('DD MMM Y')); ?>

                  </td>
                  <td class="text-center">            
                    <form action="<?php echo e(url('admin-master/delete_score',$data->id_score)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <a class="btn btn-warning btn-sm" href="<?php echo e(url('admin-master/detail_score',$data->id_score)); ?>"><i class="fas fa-edit"></i></a>
                      <button class="btn btn-danger btn-sm"><i class="fas fa-trash" onclick="return confirm('Yakin ingin menghapus data?')"></i></button>
                    </form>                  
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
              <tr>
                <th>No </th>
                <th>NIP </th>
                <th>Petugas</th>
                <th>Penilaian</th>
                <th>Keterangan</th>
                <th>Area Kerja</th>
                <th>Pengawas</th>
                <th>Kategori</th>
                <th>Tanggal</th>
                <th>Aksi</th>
              </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_admin/show_score_all.blade.php ENDPATH**/ ?>