

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('pengawas/dashboard')); ?>" style="color:#17a2b8;">Dashboard</a>
          </li>
          <li class="breadcrumb-item active"><b>Penilaian</b></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!-- /.content-header -->


<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Data Penilaian content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>        
        <?php if($message = Session::get('failed')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>        
        <?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
      </div>
      <div class="col-md-3">
          <!-- Info Boxes Style 2 -->
          <div class="card card-primary">
            <div class="card-body">
              <form action="<?php echo e(url('pengawas/search_score')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="col-md-12">
                  <label>Pilih Tanggal: </label>
                  <div class="form-group">
                    <input type="date" name="start_dt" class="form-control">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <input type="date" name="end_dt" class="form-control">
                  </div>
                </div>
                <?php if($data->is_banquet_multimedia == 1 & $data->is_gardener == 1 & $data->is_cleaning_service == 1 & $data->is_security == 1): ?>
                <div class="col-md-12">
                  <label>Pilih Petugas:</label>
                  <div class="form-group">
                    <select class="form-control" name="emp_category">
                      <option value="">-- Pilih Petugas --</option>
                      <option value="bm">BANQUET & MULTIMEDIA</option>
                      <option value="cs">CLEANING SERVICES</option>
                      <option value="sc">SECURITY</option>
                      <option value="gd">TAMAN</option>
                    </select>
                  </div>
                </div>
                <?php endif; ?>
                <div class="col-md-12">
                  <p>
                    <button class="btn btn-info btn-sm"><b>CARI</b></button>
                    <a href="<?php echo e(url('pengawas/show_score')); ?>" class="btn btn-danger btn-sm">
                      <i class="fas fa-sync"></i>
                    </a>
                  </p>
                </div>    
              </form>
            </div>
          </div>
      </div>

      <div class="col-md-9">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title-data"><b>HASIL PENILAIAN</b></h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">             
              <div class="col-md-12">
                <div class="form-group">
                  <table id="table1" class="table table-bordered table-striped" style="font-size:14px;">
                    <thead>
                      <tr>
                        <th>No </th>
                        <th>NIP </th>
                        <th>Nama</th>
                        <th>Area Kerja</th>
                        <th>Kartu Kuning</th>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $no=1;?>
                      <?php $__currentLoopData = $score; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($data->id_employee); ?></td>
                        <td><?php echo e($data->emp_name); ?></td>
                        <td>
                          <?php if($data->score_notes != null): ?>
                            <?php echo e($data->score_notes); ?>

                          <?php endif; ?>
                          <?php if($data->score_notes == null): ?>
                            <?php echo e($data->working_area_name); ?>

                          <?php endif; ?>
                        </td>
                        <td><?php echo e($data->total_score); ?> Kartu Kuning</td>
                        <td><?php echo e(date('H:i', strtotime($data->score_tm))); ?> / 
                            <?php echo e(\Carbon\Carbon::parse($data->score_dt)->isoFormat('DD MMM Y')); ?></td>
                        <td class="text-center">
                          <?php if($data->emp_category == 'CS'): ?>
                            <a class="btn btn-primary btn-sm disabled font-weight-bold">CS</a>
                          <?php endif; ?>
                          <?php if($data->emp_category == 'MM'): ?>
                            <a class="btn btn-warning btn-sm disabled font-weight-bold">MM</a>
                          <?php endif; ?>
                          <?php if($data->emp_category == 'BQ'): ?>
                            <a class="btn btn-warning btn-sm disabled font-weight-bold">BQ</a>
                          <?php endif; ?>
                          <?php if($data->emp_category == 'GD'): ?>
                            <a class="btn btn-success btn-sm disabled font-weight-bold">GD</a>
                          <?php endif; ?>
                          <?php if($data->emp_category == 'SC'): ?>
                            <a class="btn btn-dark btn-sm disabled font-weight-bold">SC</a>
                          <?php endif; ?>
                        </td>
                        <td class="text-center">                        
                          <a class="btn btn-warning btn-sm" href="<?php echo e(url('pengawas/detail_score',$data->id_score)); ?>"><b><i class="fas fa-edit"></i></b></a>
                          <!-- <a class="btn btn-info btn-sm" href="#"><b>Lokasi Kerja</b></a> -->
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>No </th>
                        <th>NIP </th>
                        <th>Nama</th>
                        <th>Area Kerja</th>
                        <th>Jumlah Kartu Kuning</th>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Aksi</th>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- /.content -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_pengawas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_pengawas/show_score.blade.php ENDPATH**/ ?>