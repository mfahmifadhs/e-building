

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('admin-master/dashboard')); ?>" style="color:#17a2b8;">Dashboard</a>
          </li>
          <li class="breadcrumb-item active"><b>Data Penyedia</b></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
        <?php if($message = Session::get('failed')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>        
        <?php if($message = Session::get('delete')): ?>
          <div class="alert alert-danger">
              <p style="margin:0;"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title-data"><b>DAFTAR PENYEDIA</b></h3>
            <a href="<?php echo e(url('admin-master/create_user')); ?>" class="btn btn-primary add-data">
              <i class="fas fa-plus-circle"></i>
            </a>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="table1a" class="table table-bordered table-striped">
              <thead align="center">
              <tr>
                <th>NO </th>
                <th>NAMA PERUSAHAAN</th>
                <th>USERNAME</th>
                <th>TOTAL PEGAWAI</th>
                <th>STATUS</th>
                <th>AKSI</th>
              </tr>
              </thead>
              <tbody align="center">
                <?php $no=1;?>
                <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($row->name); ?></td>
                  <td><?php echo e($row->username); ?></td>
                  <td><?php echo e($row->totalpegawai); ?> Pegawai</td>
                  <td>
                    <?php if($row->status_name == 'Aktif'): ?>
                      <a class="btn btn-success btn-sm disabled" style="text-transform:uppercase;"><b><?php echo e($row->status_name); ?></b></a>
                    <?php endif; ?>
                     <?php if($row->status_name == 'Tidak Aktif'): ?>
                      <a class="btn btn-danger btn-sm disabled" style="text-transform:uppercase;"><b><?php echo e($row->status_name); ?></b></a>
                    <?php endif; ?>
                  </td>
                  <td class="text-center">               
                    <a class="btn btn-warning btn-md" href="<?php echo e(url('admin-master/show_profile',$row->id)); ?>">
                      <i class="fas fa-user-edit"></i>
                    </a>               
                    <a class="btn btn-info btn-md" href="<?php echo e(url('admin-master/show_employee',$row->id)); ?>">
                      <i class="fas fa-users"></i>
                    </a>    
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot align="center">
                <tr>
                  <th>NO </th>
                  <th>NAMA PERUSAHAAN</th>
                  <th>USERNAME</th>
                  <th>TOTAL PEGAWAI</th>
                  <th>STATUS</th>
                  <th>AKSI</th>
                </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('v_admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Kemenkes_Ebuilding\resources\views/v_admin/show_vendor.blade.php ENDPATH**/ ?>